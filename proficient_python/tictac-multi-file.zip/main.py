import users
import game


def welcome_message():
    print("Welcome to Tic Tac Toe!")


def print_menu():
    print("\nMenu:")
    print("1. Add a user")
    print("2. Delete a user")
    print("3. Show all users")
    print("4. Play against the computer")
    print("5. Play against another player")
    print("6. Quit")

def add_user():
    username = input("Enter a username: ")
    users.add_user(username)


def delete_user():
    username = input("Enter a username to delete: ")
    users.delete_user(username)


def show_all_users():
    all_users = users.get_all_users()
    print("\nUsers:")
    for username, score in all_users.items():
        print(f"{username}: {score}")


def play_game(opponent):
    username1 = input("Enter the username of Player 1: ")
    if opponent == "computer":
        username2 = "computer"
    else:
        username2 = input("Enter the username of Player 2: ")

    winner = game.play(username1, username2)
    if winner:
        print(f"\n{winner} wins!")
        users.update_score(winner)


def main():
    welcome_message()
    while True:
        print_menu()
        choice = input("Choose an option: ")
        if choice == "1":
            add_user()
        elif choice == "2":
            delete_user()
        elif choice == "3":
            show_all_users()
        elif choice == "4":
            play_game("computer")
        elif choice == "5":
            play_game("player")
        elif choice == "6":
            break
        else:
            print("Invalid option. Please try again.")


if __name__ == "__main__":
    main()
