import random


def print_board(board):
    for row in board:
        print(" | ".join(row))
        print("-" * 9)


def is_winner(board, player):
    for row in board:
        if row.count(player) == 3:
            return True
    for col in range(3):
        if [board[row][col] for row in range(3)].count(player) == 3:
            return True
    if [board[i][i] for i in range(3)].count(player) == 3:
        return True
    if [board[i][2 - i] for i in range(3)].count(player) == 3:
        return True
    return False


def get_empty_cells(board):
    empty_cells = []
    for row in range(3):
        for col in range(3):
            if board[row][col] == " ":
                empty_cells.append((row, col))
    return empty_cells


def computer_move(board):
    empty_cells = get_empty_cells(board)
    return random.choice(empty_cells)


def player_move(board):
    while True:
        row = int(input("Enter the row (0-2): "))
        col = int(input("Enter the column (0-2): "))
        if (row, col) in get_empty_cells(board):
            return row, col
        print("Invalid move. Please try again.")


def play(username1, username2):
    board = [[" " for _ in range(3)] for _ in range(3)]
    current_player, next_player = username1, username2
    player_symbol = {"X": username1, "O": username2}

    while get_empty_cells(board):
        print_board(board)
        if current_player == "computer":
            row, col = computer_move(board)
        else:
            row, col = player_move(board)

        symbol = "X" if current_player == player_symbol["X"] else "O"
        board[row][col] = symbol

        if is_winner(board, symbol):
            print_board(board)
            return current_player

        current_player, next_player = next_player, current_player

    print_board(board)
    print("It's a draw!")
    return None
