import data.usersdata

USERS = data.usersdata.USERS

def add_user(username):
    if username in USERS:
        print(f"User '{username}' already exists.")
    else:
        USERS[username] = 0
        print(f"User '{username}' added.")


def delete_user(username):
    if username in USERS:
        del USERS[username]
        print(f"User '{username}' deleted.")
    else:
        print(f"User '{username}' not found.")


def get_all_users():
    return USERS


def update_score(username):
    if username in USERS:
        USERS[username] += 1
    else:
        print(f"User '{username}' not found. Cannot update score.")